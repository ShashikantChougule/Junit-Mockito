package com.training;

public class MathUtil {

	public static int addition(int x, int y) {
		return x + y;
	}

}
