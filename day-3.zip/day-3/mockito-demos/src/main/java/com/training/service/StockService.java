package com.training.service;

import com.training.model.Stock;

public interface StockService {
	
	public double getStockPrice(Stock stock);
}


